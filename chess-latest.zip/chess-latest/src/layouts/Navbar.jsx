import {useState} from 'react'
import '../layouts/navbar.css'
import { FaChess } from "react-icons/fa";
import { IoSearchOutline } from "react-icons/io5";
import { MdPermPhoneMsg } from "react-icons/md";
import { GoBell } from "react-icons/go";
import { IoVideocamOutline } from "react-icons/io5";
import { PiUserCirclePlus } from "react-icons/pi";
import { TbAppsFilled } from "react-icons/tb";
import Home from '../components/Home';

const Navbar = ({ onSearch }) => {
    const [search, setSearch] = useState('')
    console.log(search);
    const [query, setQuery] = useState('');

    const handleSearch = () => {
      onSearch(query);
    };
  return (
    <div>
        <header className="masthead">

<div className="logo">
    <a href="#">
        <h2><i className="logo-icon" aria-hidden="true"></i><FaChess />LeaderBoard</h2>
    </a>
</div>

<div className="site-search">
    <input type="search" placeholder="Search" className="search-input" aria-label="Search" value={query}
    onChange={(e) => setQuery(e.target.value)} />
    <button className="search-btn" aria-label="Search" onClick={handleSearch}><i className="fas fa-search" aria-hidden="true"><IoSearchOutline /></i></button>
    
</div>

<div className="user-menu">

    <button className="btn" aria-label="YouTube Apps">
            <i className="fas fa-th" aria-hidden="true"><TbAppsFilled /></i>
        </button>

    <button className="btn" aria-label="Notifications">
            <i className="fas fa-bell" aria-hidden="true"><MdPermPhoneMsg /></i>
        </button>

    <button className="btn" aria-label="Account">
            <i className="fas fa-user-circle" aria-hidden="true"><PiUserCirclePlus /></i>
        </button>

</div>

</header>
    </div>
  )
}

export default Navbar