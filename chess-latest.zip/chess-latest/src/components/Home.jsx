import axios from "axios";
import React, { useEffect, useState } from "react";
import "../components/home.css";
import { IoSearchOutline } from "react-icons/io5";
import Navbar from "../layouts/Navbar";

const Home = ({ searchResults }) => {
  const [data, setData] = useState([]);
  const [individual, setIndividual] = useState([])
  const [players, setPlayers] = useState([]);
  const [filterPlayers, setFilterPlayers] = useState([]);

  // console.log(xyz.getData(search));
  // const handleChange=(e)=>{
  //   e.preventDefault()
  //   setSearch(e.target.value)
  // }
  // console.log(homesearch);
  console.log(searchResults);
  const getapi = async () => {
    try {
      let res = await axios.get("https://api.chess.com/pub/leaderboards");
      setData(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  console.log(individual);
  console.log(data);

  function Items1   ()  {
   const x =  data.daily
    setIndividual(x);
  };
  function Items2   ()  {
    const x =  data.daily960
     setIndividual(x);
   };
   function Items3   ()  {
    const x =  data.live_rapid
     setIndividual(x);
   };
   function Items4   ()  {
    const x =  data.live_blitz
     setIndividual(x);
   };
   function Items5   ()  {
    const x =  data.live_bullet
     setIndividual(x);
   };
   function Items6   ()  {
    const x =  data.live_bughouse
     setIndividual(x);
   };
   function Items7   ()  {
    const x =  data.live_blitz_960
     setIndividual(x);
   };
   function Items8   ()  {
    const x =  data.live_three_check
     setIndividual(x);
   };
   function Items9   ()  {
    const x =  data.live_crazy_house
     setIndividual(x);
   };
   function Items10   ()  {
    const x =  data.live_king_of_the_hill
     setIndividual(x);
   };
   function Items11   ()  {
    const x =  data.tactics
     setIndividual(x);
   };
   function Items12  ()  {
    const x =  data.rush
     setIndividual(x);
   };
   function Items13  ()  {
    const x =  data.battle
     setIndividual(x);
   };

  console.log(data);
  console.log(players);
  useEffect(() => {
    getapi();
  }, []);

  return (
    <>
      <section className="home-banner">
        <div className="banner"></div>
        <div className="container">
          <div className="layout">
            <p className="col col-main">
              <input
                type="search"
                placeholder="Search"
                className="search-input2"
                aria-label="Search"
              />
              <button className="search-btn2" aria-label="Search">
                <i className="fas fa-search" aria-hidden="true">
                  <IoSearchOutline />
                </i>
              </button>
              <br />
              <strong>Category</strong>
              <br />

              <div className="radio">
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items1}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Daily
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items2}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Daily960
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items3}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  live Rapid
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items4}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Live Blitz
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items5}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Live Bullet
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items6}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Live Bughouse
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items7}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Live Blitz 960
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items8}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Live Three Check
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items9}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Live Crazy House
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items10}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Live King of the hill
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items11}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Tactics
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items12}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Rush
                </label>
                <br />
                <input
                  className="form-check-input"
                  type="radio"
                  name="flexRadioDefault"
                  id="flexRadioDefault1"
                  onClick={Items13}
                />
                <label className="form-check-label" htmlFor="flexRadioDefault1">
                  Battle
                </label>
                <br />
              </div>
            </p>
            <p className="col col-complementary" role="complementary">
              <table>
                <thead>
                  <tr>
                    <th>Avtar</th>
                    <th>Player_Id</th>
                    <th>Rank</th>
                    <th>Name</th>
                    <th>Score</th>
                    {/* <th>Country</th> */}
                    {/* Add more table headers as needed */}
                  </tr>
                </thead>
                <tbody>
                  {individual
                    .filter((element) =>
                      // console.log(element.username.includes(homesearch))

                      element.username.toLowerCase().includes(searchResults)
                    )
                    .map((item) => (
                      <tr key={item.id}>
                        <td>
                          <img
                            src={item.avatar}
                            alt=""
                            height={"50px"}
                            width={"50px"}
                          />
                        </td>
                        <td>{item.player_id}</td>
                        <td>{item.rank}</td>
                        <td>{item.username}</td>
                        <td>{item.score}</td>
                        {/* <td>{res}</td> */}
                        {/* Add more table cells for additional data */}
                      </tr>
                    ))}
                </tbody>
              </table>
              <br />
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
