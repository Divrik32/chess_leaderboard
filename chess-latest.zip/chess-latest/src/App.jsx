
//import './App.css'

import { Route, Routes } from "react-router-dom"
import Home from "./components/Home"
import Navbar from "./layouts/Navbar"
import { useState } from "react";

function App() {
  
  const [searchResults, setSearchResults] = useState([]);
  
  const handleSearch = (query) => {
    // Perform search operation here, for example:
    // const results = ['Result 1', 'Result 2', 'Result 3']; // Replace with your actual search logic
    setSearchResults(query.toLowerCase());
  };

  return (
    <>
    <Navbar onSearch={handleSearch} />
    <Routes>
      <Route path="/" element={<Home searchResults={searchResults}/>} />
      <Route path="/" element={<Home/>} />
      <Route path="/" element={<Home/>} />
    </Routes>
     
    </>
  )
}

export default App
